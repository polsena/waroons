# TODO

## v1.0
  - Create real italic styles for all weights
  - Improve all combining diacritics
  - Support more European & Vietnam languages
  - Add Lao glyphs

##  v0.6
  - Add 300 (Light) & 500 (Medium) or 600 (Semi-Bold) weights
  - Add font weight, text, background color pickers to index page (javascript?)

##  Other features
  - Latin small cap
  - Alternate styles: a,g, gemandbls
  - Greek & Cyrillic ?
  - Use Python module to generate all fonts, see <http://fontforge.org/python.html>
